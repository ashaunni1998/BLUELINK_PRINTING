

export default 'https://kerala-digital-park-server.vercel.app/api'
// export default "http://localhost:3000/api"

