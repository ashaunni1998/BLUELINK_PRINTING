import React, { useState, useEffect } from 'react';
import { ArrowRight, Sparkles, Heart, FileText, Gift, Star, Zap, Eye } from 'lucide-react';
import { Link } from "react-router-dom";
const EnhancedHomeSections = () => {
  const [visibleSections, setVisibleSections] = useState({});
  const [hoveredCard, setHoveredCard] = useState(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleSections(prev => ({
              ...prev,
              [entry.target.id]: true
            }));
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('[data-animate]').forEach((el) => {
      observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const [windowWidth, setWindowWidth] = useState(typeof window !== 'undefined' ? window.innerWidth : 1440);

useEffect(() => {
  const handleResize = () => {
    setWindowWidth(window.innerWidth);
  };
  window.addEventListener('resize', handleResize);
  return () => window.removeEventListener('resize', handleResize);
}, []);

// ADD this helper function:
const getPadding = () => {
  if (windowWidth <= 768) return '1rem';
  if (windowWidth < 1200) return '1.5rem';
  return '2.5rem';
};


const padding = getPadding();


  return (
    <div className="relative bg-white">
      
      {/* Blog/Examples Section */}
  <section 
  id="blog-section"
  data-animate
  className={`relative overflow-hidden transition-all duration-1000 ${
    visibleSections['blog-section'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
  }`}
  style={{ width: "100%", margin: "0", padding: "0" }}
>
  {/* Container matching Header layout */}
  <div style={{
    maxWidth: "1440px",
    margin: "0 auto",
    padding: `${windowWidth <= 768 ? '3rem 1rem' : windowWidth < 1200 ? '4rem 1.5rem' : '5rem 2.5rem'}`,
    boxSizing: "border-box",
    width: "100%",
  }}>
    <div className="relative z-10">
      {/* Section Header */}
      <div className="text-center mb-12 md:mb-16">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 border border-blue-200 rounded-full text-blue-700 text-sm font-medium mb-6">
          <Eye className="w-4 h-4" />
          Design Inspiration
        </div>
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-gray-900 mb-4">
          Creative <span className="text-blue-600">Showcase</span>
        </h2>
        <div className="w-24 h-1 bg-blue-600 rounded-full mx-auto" />
      </div>

      {/* Cards Grid */}
      <div className="grid lg:grid-cols-2 gap-6 md:gap-8 items-stretch">          
        {/* Business Cards Card */}
        <div 
          className={`group relative bg-white rounded-3xl overflow-hidden border-2 border-blue-200 transform transition-all duration-500 hover:scale-105 flex flex-col h-full ${
            hoveredCard === 'business' ? 'scale-105' : ''
          }`}
          onMouseEnter={() => setHoveredCard('business')}
          onMouseLeave={() => setHoveredCard(null)}
        >
          {/* Image Container */}
          <div className="relative overflow-hidden">
            <img
              src="/homeimages/business-cards-sample.jpg"
              alt="Business Card Examples"
              className="w-full h-64 md:h-72 lg:h-80 object-cover transform group-hover:scale-110 transition-transform duration-700"
            />
            <div className="absolute top-4 right-4 bg-white px-3 py-1.5 rounded-full text-xs font-semibold text-blue-600 border-2 border-blue-200">
              <Sparkles className="w-3 h-3 inline mr-1" />
              Featured
            </div>
          </div>

          {/* Content */}
          <div className="p-6 md:p-8 flex flex-col flex-grow">
            <div className="flex-grow">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-xl md:text-2xl font-bold text-gray-900 leading-tight pr-2">
                  10 Business Card Examples
                </h3>
                <FileText className="w-6 h-6 text-blue-500 flex-shrink-0 mt-1" />
              </div>

              <p className="text-base md:text-lg text-gray-600 leading-relaxed mb-6">
                Blue Link's designers share 10 standout business cards from different industries that combine creative layouts with premium finishes. Discover how smart use of color, typography, and unique printing techniques can instantly elevate your brand's first impression.
              </p>
            </div>

            {/* Stats + Button */}
            <div className="mt-auto">
              <div className="flex items-center gap-6 mb-5">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="text-sm text-gray-600 ml-1">4.9</span>
                </div>
                <span className="text-sm text-gray-500">1.2k views</span>
              </div>
              <Link
                to="/blog/5"
                state={{ from: "home" }}
                className="group/btn w-full flex items-center justify-center gap-2 px-6 py-4 bg-blue-600 text-white font-semibold rounded-2xl transform transition-all duration-300 hover:scale-105"
              >
                Read More
                <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </div>

        {/* Invites Card */}
        <div 
          className={`group relative bg-white rounded-3xl overflow-hidden border-2 border-blue-200 transform transition-all duration-500 hover:scale-105 flex flex-col h-full ${
            hoveredCard === 'invites' ? 'scale-105' : ''
          }`}
          onMouseEnter={() => setHoveredCard('invites')}
          onMouseLeave={() => setHoveredCard(null)}
        >
          {/* Image Container */}
          <div className="relative overflow-hidden h-64 md:h-72 lg:h-80">
            <img
              src="/homeimages/invites-sample.jpg"
              alt="Event Invitations"
              className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
            />
            <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full text-xs font-semibold text-blue-600 border-2 border-blue-200">
              <Heart className="w-3 h-3 inline mr-1" />
              Popular
            </div>
          </div>

          {/* Content */}
          <div className="p-6 md:p-8 flex flex-col flex-grow">
            <div className="flex-grow">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-xl md:text-2xl font-bold text-gray-900 leading-tight pr-2">
                  Invites They Won't Ignore
                </h3>
                <Heart className="w-6 h-6 text-blue-500 flex-shrink-0 mt-1" />
              </div>

              <p className="text-base md:text-lg text-gray-600 leading-relaxed mb-6">
                Master the art of creating paper invites that actually get a "yes" with these proven design strategies and tips. From choosing the perfect color palette to selecting premium paper finishes, every detail matters in making your invitation stand out.
              </p>
            </div>

            {/* Stats + Button */}
            <div className="mt-auto">
              <div className="flex items-center gap-6 mb-5">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="text-sm text-gray-600 ml-1">4.8</span>
                </div>
                <span className="text-sm text-gray-500">850 views</span>
              </div>
              <Link
                to="/blog/6"
                state={{ from: "home" }}
                className="group/btn w-full flex items-center justify-center gap-2 px-6 py-4 bg-blue-600 text-white font-semibold rounded-2xl transform transition-all duration-300 hover:scale-105"
              >
                Read More
                <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
      {/* Flyers Section */}
 <section 
      id="flyers-section"
      data-animate
      className={`relative overflow-hidden transition-all duration-1000 delay-200 bg-blue-50 ${
        visibleSections?.['flyers-section']
          ? 'opacity-100 translate-y-0'
          : 'opacity-0 translate-y-10'
      }`}
      style={{ width: "100%", margin: "0", padding: "0" }}
    >
      {/* Outer centered container - matches Header.topBar structure */}
      <div style={{
        maxWidth: "1440px",
        margin: "0 auto",
        width: "100%",
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
      }}>
        {/* Inner padding wrapper - matches Header.navLinks padding */}
        <div style={{
          paddingLeft: padding,
          paddingRight: padding,
          paddingTop: windowWidth < 1050 ? '1.5rem' : '1.875rem',
          paddingBottom: windowWidth < 1050 ? '2rem' : '2.5rem',
          boxSizing: "border-box",
          flex: 1,
        }}>
          <div className="relative z-10">
            <div className="grid lg:grid-cols-2 gap-8 md:gap-10 lg:gap-12 xl:gap-16 items-center">     
              
              {/* Image Side */}
             <div className="relative group order-2 lg:order-1">
  <div className="relative bg-white p-4 md:p-6 rounded-2xl md:rounded-3xl border-2 border-blue-200 max-w-2xl mx-auto">
    <img
      src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQd19vInA8bUX20OregUR32xvV6CbNZ_kMhDQ&s"
      alt="Flyers & Leaflets"
      className="w-full h-64 md:h-80 lg:h-96 object-cover rounded-xl md:rounded-2xl transform group-hover:scale-105 transition-transform duration-500"
    />
  

                  
                  {/* Fast Delivery Badge */}
                  <div className="absolute -top-4 -right-4 bg-white rounded-xl md:rounded-2xl p-3 md:p-4 border-2 border-blue-200 shadow-lg">
                    <div className="text-center">
                      <div className="text-lg md:text-xl lg:text-2xl font-black text-blue-600">Fast</div>
                      <div className="text-xs md:text-sm text-gray-600 font-medium">Delivery</div>
                    </div>
                  </div>
                  
                  {/* HD Quality Badge */}
                  <div className="absolute -bottom-4 -left-4 bg-blue-600 text-white rounded-xl md:rounded-2xl p-3 md:p-4 shadow-lg">
                    <div className="text-center">
                      <div className="text-lg md:text-xl lg:text-2xl font-black">HD</div>
                      <div className="text-xs md:text-sm font-medium">Quality</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Content Side */}
              <div className="space-y-6 md:space-y-8 order-1 lg:order-2">
                
                {/* Badge */}
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 border border-blue-200 rounded-full text-blue-700 text-sm font-medium">
                  <FileText className="w-4 h-4" />
                  Marketing Materials
                </div>

                {/* Heading */}
                <div className="space-y-4 md:space-y-6">
                  <h2 className="text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-black text-gray-900 leading-tight">
                    Flyers & Leaflets.
                    <span className="block text-blue-600">Spread the word.</span>
                  </h2>
                  <div className="w-24 h-1 bg-blue-600 rounded-full" />
                </div>

                {/* Description */}
                <p className="text-base md:text-lg lg:text-xl text-gray-700 leading-relaxed">
                  Make your message loud and clear with professional, high-impact flyers and leaflets – 
                  perfect for <span className="text-blue-600 font-semibold">promotions</span>, 
                  <span className="text-blue-600 font-semibold"> menus</span>, and so much more.
                </p>

                {/* Features Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[
                    { icon: Zap, text: "Same-day printing" },
                    { icon: Star, text: "Premium papers" },
                    { icon: Sparkles, text: "Custom designs" },
                    { icon: Heart, text: "Expert support" }
                  ].map((feature, index) => (
                    <div 
                      key={index} 
                      className="flex items-center gap-3 p-3 md:p-4 bg-blue-100 rounded-xl border border-blue-200 hover:bg-blue-200 hover:scale-105 transition-all duration-300 cursor-pointer"
                    >
                      <feature.icon className="w-5 h-5 md:w-6 md:h-6 text-blue-500 flex-shrink-0" />
                      <span className="text-sm md:text-base font-medium text-gray-700 leading-tight">{feature.text}</span>
                    </div>
                  ))}
                </div>

                {/* CTA Buttons */}
                <div className="flex flex-col sm:flex-row gap-4 pt-2">
                  <button className="group flex items-center justify-center gap-2 px-6 md:px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white text-base font-bold rounded-2xl transform transition-all duration-300 hover:scale-105 w-full sm:w-auto">
                    <span className="whitespace-nowrap">Shop Flyers & Leaflets</span>
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform flex-shrink-0" />
                  </button>
                  <button className="px-6 md:px-8 py-4 border-2 border-blue-400 text-blue-600 text-base font-semibold rounded-2xl bg-white hover:bg-blue-50 hover:scale-105 transition-all duration-300 w-full sm:w-auto">
                    View Samples
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

      {/* Gifts Section */}
  <section 
  id="gifts-section"
  data-animate
  className={`relative overflow-hidden transition-all duration-1000 delay-400 ${
    visibleSections['gifts-section'] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
  }`}
  style={{ width: "100%", margin: "0", padding: "0" }}
>
  {/* Outer centered container - matches Header.topBar structure */}
  <div style={{
    maxWidth: "1440px",
    margin: "0 auto",
    width: "100%",
    boxSizing: "border-box",
    display: "flex",
    flexDirection: "column",
  }}>
    {/* Inner padding wrapper - matches Header.navLinks padding */}
    <div style={{
      paddingLeft: getPadding(),
      paddingRight: getPadding(),
      paddingTop: windowWidth < 1050 ? '1.5rem' : '1.875rem',
      paddingBottom: windowWidth < 1050 ? '2rem' : '2.5rem',
      boxSizing: "border-box",
      flex: 1,
    }}>
      <div className="relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 md:gap-12 items-center">
 
          {/* Content Side */}
          <div className="space-y-6 md:space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 border border-blue-200 rounded-full text-blue-700 text-sm font-medium">
              <Gift className="w-4 h-4" />
              Custom Products
            </div>

            <div className="space-y-4 md:space-y-6">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-gray-900 leading-tight">
                Personalized Gifts.
                <span className="block text-blue-600">Make it special.</span>
              </h2>
              <div className="w-24 h-1 bg-blue-600 rounded-full" />
            </div>

            <p className="text-base md:text-lg lg:text-xl text-gray-700 leading-relaxed">
              Add a personal touch with custom gifts perfect for any occasion – from 
              <span className="text-blue-600 font-semibold"> birthdays</span> to 
              <span className="text-blue-600 font-semibold"> business branding</span> and everything in between.
            </p>

            {/* Features */}
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Heart, text: "Unique designs" },
                { icon: Sparkles, text: "Premium quality" },
                { icon: Gift, text: "Gift wrapping" },
                { icon: Star, text: "Fast turnaround" }
              ].map((feature, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-blue-100 rounded-xl border border-blue-200">
                  <feature.icon className="w-5 h-5 text-blue-500" />
                  <span className="text-sm font-medium text-gray-700">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* CTA */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="group flex items-center justify-center gap-2 px-6 lg:px-8 py-4 bg-blue-600 text-white font-bold rounded-2xl transform transition-all duration-300 hover:scale-105">
                Shop Personalized Gifts
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="px-6 lg:px-8 py-4 border-2 border-blue-400 text-blue-600 font-semibold rounded-2xl bg-white hover:bg-blue-50 transition-all duration-300">
                Browse Gallery
              </button>
            </div>
          </div>

          {/* Image Side */}
          <div className="relative">
            <div className="relative max-w-lg-1 mx-auto lg:mx-0">
              <img
                src="https://thesignaturebox.com/cdn/shop/articles/personalised-gifts-5-things-to-consider-before-choosing-personalized-gifts-294055.jpg?v=1706979689&width=1280"
                alt="Personalized Gift"
                className="w-full rounded-2xl shadow-lg"
              />
              
              {/* 100% Custom Badge - Top Left */}
              <div className="absolute -top-3 -left-3 bg-white rounded-xl px-3 py-2 shadow-lg border border-gray-200">
                <div className="text-center">
                  <div className="text-base font-bold text-blue-600">100%</div>
                  <div className="text-xs text-gray-600 uppercase tracking-wide">Custom</div>
                </div>
              </div>

              <div className="absolute -bottom-3 -right-3 bg-blue-600 text-white rounded-xl p-3 shadow-lg">
                <div className="text-center">
                  <div className="text-xl">🎁</div>
                  <div className="text-xs">Special</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
    </div>
  );
};

export default EnhancedHomeSections;